print("Hello World")
print("Hello World ! How are you?")
print ( 123)

# The variable `message` is assigned a text string value
message = "Hello World"
print(message)
# The variable `my_number` is assigned a numeric value
my_number = 29

# The variable `my_message` is assigned to the value of another variable
my_message = message
# Add two numbers
print(2+10)
message = """this is a long 
multiline string"""

print(message)
user_update_payment_info = False
edit_content = True

# What is your name?
# How old are you?
# How many months is that?

str_Name = "What is your name"
str_Age = "How old are you?"
str_Months = "How many months is that?"

# My name is "Billy".
# 30
# 360

str_Ans_Name = "My name is \"Billy\"."
int_Age = 30
int_Months = 360

print(str_Name)
print(str_Ans_Name)
print(str_Age)
print(int_Age)
print(str_Months)
print(int_Months)



#my_string, my_integer, and my_float
my_string = "Python is fun"
my_integer = 20
my_float = 21.68

print(my_float)
print(my_integer)
print(my_string)



